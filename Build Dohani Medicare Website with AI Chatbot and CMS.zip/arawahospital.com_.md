# Home - Arawa Hospital

**URL:** https://arawahospital.com/

---

Skip to content
Call: +254-113-838-589
Email:customercare@arawahospital.com
Home
About Us
Patients & Visitors
Our Services
Doctors Profiles & Consultant Clinics
Careers
Contact Us
News & Blog
The Care You Deserve
Our Services
General Medicine
High Dependence Unit
Pharmacy
Consultation Clinics
Gynaecology & Fertility
Children Clinics
Contact Us

+254-113-838-589.

customercare@arawahospital.com
UPCOMING EVENTS
Check out for our events
and community engagement
projects.
About the Hospital

Arawa hospital Limited is a regional healthcare facility situated at the heart of Bamburi in Mombasa. It is a fully fledged Kenyan registered hospital   that was established in March 2020 with a view of bringing hope and a new approach on healthcare in Mombasa region.

Learn More
"i believe that the greatest gift you can give your family and the world is a healthy you" 
Joyce Meyer.
Client Feedback
Our Insurance Partners
Socials
Arawa Hospital
Arawa Hospital
Important Links.
Contact Us
+254-113-838-589

customercare@arawahospital.com

+254-113-838-589
customercare@arawahospital.com
Chat here live
